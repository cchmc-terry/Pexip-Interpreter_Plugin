export const roomDirectory = {
  videoRooms: [
    {
      label: "Spanish",
      id: "spanish@example.com",
    },
    {
      label: "German",
      id: "german@example.com",
    },
    {
      label: "French",
      id: "french@example.com",
    },
    {
      label: "Portuguese",
      id: "portuguese@example.com",
    },
  ],
} as const;

