**
WebApp3 Video Directory - Video Room**

Call a SIP Video room from within a Pexip Meeting

Modify the rooms.ts (json) to suit your directory needs


# Getting started

## Run the plugin

```
yarn start
```

## Build the plugin

```
yarn build
```
